/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"

#include "fmc_imageon_hdmi_framebuffer.h"
fmc_imageon_hdmi_framebuffer_t demo;

#include "xstatus.h"
#include "simple_register.h"
#include "xparameters.h"

#include "xgpio.h"

#define GPIO_EXAMPLE_DEVICE_ID  XPAR_LEDS_8BITS_DEVICE_ID


//void print(char *str);
void print( const char *str);

int main()
{
	int bypass_mode = 1;

	init_platform();

	// initialize with bypass mode
    demo.uBaseAddr_IIC_FmcImageon = XPAR_FMC_IMAGEON_IIC_0_BASEADDR;
    demo.uDeviceId_VTC_HdmiiDetector = XPAR_V_TC_0_DEVICE_ID;
    demo.uDeviceId_VTC_HdmioGenerator = XPAR_V_TC_1_DEVICE_ID;
    demo.uDeviceId_VDMA_HdmiFrameBuffer = XPAR_AXI_VDMA_0_DEVICE_ID;
    demo.uBaseAddr_MEM_HdmiFrameBuffer = XPAR_DDR_MEM_BASEADDR + 0x10000000;
    demo.uNumFrames_HdmiFrameBuffer = XPAR_AXIVDMA_0_NUM_FSTORES;

    fmc_imageon_hdmi_framebuffer_init( &demo );

    int loop = 1;
    int current_filter_mode = 0; //default filter mode is original
    int scale_factor = 0;	//scale factor has a range from 0 to 9. Press '+' to increase, '-' to decrease
    while (loop) {
        char i[100];
        xil_printf( "Choose filter mode : \n\r");
        xil_printf( "\t '0': original\n\r\t \t '1': sharpen\n\r\t '2': edgeDetection\n\r\t '3': blur\n\r\t '4': identity\n\r\t '5': emboss\n\r\t '6': sobel\n\r\t '7': mix(blur+edgeD)\n\r");
        xil_printf( "\t 'n': next scale in same mode\n\r\t 'other_key' : switch to bypass and exit \n\r");
        fgets(i,100,stdin);
        fflush(stdout);

        switch (i[0]) {
        	case '0' :
        		// every time switch between mode, reset scale factor to default
        			scale_factor = 0;
            		current_filter_mode = 0;
        			xil_printf( "Switched to original mode ...\n\r" );
            		original(scale_factor);
        	case '1' :
        		if (current_filter_mode != 1) {
        		// every time switch between mode, reset scale factor to default
        			scale_factor = 0;
            		current_filter_mode = 1;
            		xil_printf( "Switched to sharpen mode ...\n\r" );
            		sharpen(scale_factor);
        		}
        	break;

        	case '2' :
        		if (current_filter_mode != 2) {
        		// every time switch between mode, reset scale factor to default
        			scale_factor = 0;
            		current_filter_mode = 2;
            		xil_printf( "Switched to edge detection mode ...\n\r" );
            		edgeDetection(scale_factor);
        		}
        	break;

        	case '3' :
        		if (current_filter_mode != 3) {
        		// every time switch between mode, reset scale factor to default
        			scale_factor = 0;
            		current_filter_mode = 3;
        			xil_printf( "Switched to blur mode ...\n\r" );
            		blur(scale_factor);
        		}
        	break;

        	case '4' :
        		if (current_filter_mode != 4) {
        			scale_factor = 0;
            		current_filter_mode = 4;
        			xil_printf( "Switched to identity mode ...\n\r" );
            		identity(scale_factor);
        		}
        	break;

        	case '5' :
        		if (current_filter_mode != 5) {
        			scale_factor = 0;
            		current_filter_mode = 5;
        			xil_printf( "Switched to emboss mode ...\n\r" );
            		emboss(scale_factor);
        		}
        	break;

        	case '6' :
        		if (current_filter_mode != 6) {
        			scale_factor = 0;
            		current_filter_mode = 6;
        			xil_printf( "Switched to sobel mode ...\n\r" );
            		sobel(scale_factor);
        		}
        	break;

        	case '7' :
        		if (current_filter_mode != 7) {
        			scale_factor = 0;
            		current_filter_mode = 7;
        			xil_printf( "Switched to mix mode ...\n\r" );
            		mix();
        		}
        	break;

        	case 'n' :
        		scale_factor = (scale_factor + 1) % 3;
        		switch (current_filter_mode) {
        			case 1 : sharpen(scale_factor); break;
        			case 2 : edgeDetection(scale_factor); break;
        			case 3 : blur(scale_factor); break;
        			case 4 : identity(scale_factor); break;
        			case 5 : emboss(scale_factor); break;
        			case 6 : sobel(scale_factor); break;
        			default : break;
        		}
        	break;

        	default  : loop = 0; break;
        }
    }
    // Always switch to bypass mode at the end
    bypass_mode = 1;
    filter_ip_bypass_mode(bypass_mode);

    cleanup_platform();

    return 0;
}
